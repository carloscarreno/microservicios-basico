package com.igp.jwt.tokenservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TokenserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
